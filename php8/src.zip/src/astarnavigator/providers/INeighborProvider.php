<?php

interface INeighborProvider
{
	public function getNeighbors(PathTile $tile);
}

