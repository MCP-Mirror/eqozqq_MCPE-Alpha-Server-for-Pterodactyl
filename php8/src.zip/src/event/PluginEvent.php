<?php


/**
 * Plugins that create events must use this class as the base
 */

abstract class PluginEvent extends BaseEvent{

}