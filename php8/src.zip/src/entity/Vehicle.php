<?php

abstract class Vehicle extends Entity implements Rideable{
	const CLASS_TYPE = ENTITY_OBJECT;
}